<?php  
if (isset($_POST['send'])) {
	echo "Hola";
}


?>

<!-- $_FILES['imagen'] -->